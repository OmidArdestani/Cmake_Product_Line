#include "sharedassets.h"

SharedAssets::SharedAssets() {}
